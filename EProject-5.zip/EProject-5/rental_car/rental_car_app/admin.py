from django.contrib import admin
from .models import post_testimonial,contact,brand,car,aboutus,package,booking
admin.site.register(post_testimonial)
admin.site.register(contact)
admin.site.register(brand)
admin.site.register(car)
admin.site.register(aboutus)
admin.site.register(package)
admin.site.register(booking)
