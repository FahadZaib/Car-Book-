from django.db import models


class post_testimonial(models.Model):
    Id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=50,default ="")
    description = models.CharField(max_length=250,default ="")
    name = models.CharField(max_length=50,default ="")
    email = models.CharField(max_length=50,default ="")

    def __str__(self):
        return self.title

class contact(models.Model):
    Id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    subject = models.CharField(max_length=50)
    message = models.CharField(max_length=250)
    def __str__(self):
        return self.name

class brand(models.Model):
    Id = models.AutoField(primary_key=True)
    brand_name = models.CharField(max_length=50)
    brand_description = models.CharField(max_length=50)
    brand_country = models.CharField(max_length=250)
    img = models.ImageField(upload_to='brand_images/', blank=False, null=False, default='')
    def __str__(self):
        return self.brand_name


class car(models.Model):
    Id = models.AutoField(primary_key=True)
    brand_id = models.ForeignKey(brand, on_delete=models.CASCADE)
    car_name = models.CharField(max_length=50)
    car_model = models.CharField(max_length=50,default ="")
    car_mileage= models.CharField(max_length=250,default ="")
    car_description= models.CharField(max_length=250,default ="")
    car_transmission= models.CharField(max_length=250,default ="")
    car_seats= models.CharField(max_length=250,default ="")
    car_luggage= models.CharField(max_length=250,default ="")
    car_fuel= models.CharField(max_length=250,default ="")
    img = models.ImageField(upload_to='car_images/', blank=False, null=False, default='')
    def __str__(self):
        return self.car_name

class aboutus(models.Model):
    Id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=50)
    description = models.CharField(max_length=550)
    def __str__(self):
        return self.title

class package(models.Model):
    Id = models.AutoField(primary_key=True)
    per_hour = models.CharField(max_length=50,default ="")
    per_day = models.CharField(max_length=50,default ="")
    per_month = models.CharField(max_length=50,default ="")
    driver = models.CharField(max_length=50)
    car_id = models.ForeignKey(car, on_delete=models.CASCADE)
    def __str__(self):
        return self.per_hour

class booking(models.Model):
    Id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50,default ="")
    date = models.DateField()
    booking_package = models.CharField(max_length=50,default ="")
    package_Id = models.ForeignKey(package, on_delete=models.CASCADE)
    def __str__(self):
        return self.name
