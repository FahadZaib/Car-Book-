from django.http import HttpResponse
from django.shortcuts import render,redirect
from .models import car,brand,contact,aboutus,package,post_testimonial,booking
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout

def index(request):
    fetch_car = car.objects.all().order_by("-Id")[:3]
    fetch_brand = brand.objects.all().order_by("-Id")[:3]
    fetch_details = aboutus.objects.all().order_by("-Id")[:1]
    fetch_contact = contact.objects.all().order_by("-Id")[:3]

    total_data = {
        "car": fetch_car,
        "brand": fetch_brand,
        "about": fetch_details,
        "contact": fetch_contact,
    }
    return render(request,"index.html",total_data)

def blog(request):
    return render(request,"blog.html")
def blog_single(request):
    return render(request,"blog_single.html")
def cars(request):
    return render(request,"car.html")
def car_single(request):
    return render(request,"car_single.html")
def about(request):
    fetch_details = aboutus.objects.all().order_by("-Id")[:1]
    user_details = post_testimonial.objects.all().order_by("-Id")[:3]

    if request.method == "POST":
        title = request.POST["title"]
        des = request.POST["message"]
        name = request.user.username
        email = request.user.email
        insert = post_testimonial.objects.create(name=name, email=email,title=title,description=des)
        insert.save()
        mssg = "Your Testimonial has been posted suessfully "
        return render(request,"about.html",{"m" : mssg})
    total_data = {
        "about": fetch_details,
        "user": user_details,

    }
    return render(request,"about.html",total_data)
def contacts(request):
    if request.method == "POST":
        name = request.POST["name"]
        email = request.POST["email"]
        subject = request.POST["subject"]
        msg = request.POST["msg"]
        insert = contact.objects.create(name=name, email=email,subject = subject, message=msg)
        insert.save()
        mssg = "Your request has been suessfully submited"
        return render(request,"contact.html",{"m" : mssg})
    return render(request,"contact.html")
def pricing(request):
        fetch_details = package.objects.all()
        fetch_car = car.objects.all()
        total_data = {
        "prince": fetch_details,
        "car":fetch_car,
        }
        return render(request,"pricing.html",total_data)
def services(request):

    return render(request,"services.html")

def packages(request):
    return render(request,"pricing.html")

def signup(request):
    return render(request,"signup.html")

def car_details(request,Id):
        fetch_car = car.objects.get(Id=Id)

        return render(request,"car_single.html",{"cars":fetch_car})

def signUp(request):
    if request.user.is_authenticated:
        return redirect("/")
    if request.method == "POST":
        name = request.POST["name"]
        email = request.POST["email"]
        pswd = request.POST["pswd"]
        Cpswd = request.POST["confirmpassword"]
        user = User.objects.create_user(name,email,pswd)
        user.save()
        if len(name) > 15:
            messages.error(request,"Username must under 15 characters")
            return redirect("/")
        if name.isalnum() == False:
            messages.error(request,"Username contains only numbers and letters")
            return redirect("/")
        if pswd != Cpswd:
            messages.error(request,"Password didn't match")
            return redirect("/")

        login(request, user)
        messages.success(request,"User Successfully Signed Up")
        return redirect("/")
    else:
        return HttpResponse("<h4> 404 not found </h4>")

def logins(request):
    if request.method == "POST":
        name = request.POST["uname"]
        pswd = request.POST["upswd"]
        user = authenticate(username = name, password = pswd )

        if user is not None:
            login(request,user)
            messages.success(request, "Successfully Logged in ")
            return redirect("/")
        else:
            messages.success(request, "Invalid Credentials,Please try again later")
            return redirect("/")
    else:
        return HttpResponse("<h4> 404 not found </h4>")

def logOut(request):
    logout(request)
    messages.success(request, " LOGGED OUT ")
    return redirect("/")

def bookingg(request,Id):
    package_fetch = package.objects.get(Id=Id)
    if request.method == "POST":
        name = request.user.username
        date = request.POST["date"]
        packages = request.POST["pac"]
        pck_id = request.POST["pck_id"]
        # user = authenticate( )
        insert = booking.objects.create(name=name, date=date, booking_package=packages,package_Id=package_fetch)
        insert.save()
        request.session["msg"] = "Your booking has been conformed"
        return redirect("/",m = request.session["msg"])


    return render(request,"Booking.html",{"pack":package_fetch})

def booking_history(request):
        fetch_car = booking.objects.all().filter(name__icontains=request.user.username)

        return render(request,"booking_history.html",{"cars" : fetch_car})
